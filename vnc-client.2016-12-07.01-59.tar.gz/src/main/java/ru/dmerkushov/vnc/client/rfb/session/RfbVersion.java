/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.dmerkushov.vnc.client.rfb.session;

/**
 *
 * @author dmerkushov
 */
public enum RfbVersion {
	Rfb33, Rfb37, Rfb38

}
